self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8742400f294033e4a01d8db18f630a67",
    "url": "/picsome/index.html"
  },
  {
    "revision": "d0d9dd568c0e00ce61ef",
    "url": "/picsome/static/css/main.6d28b708.chunk.css"
  },
  {
    "revision": "f23391500bc1a595d593",
    "url": "/picsome/static/js/2.a638863b.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/picsome/static/js/2.a638863b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d0d9dd568c0e00ce61ef",
    "url": "/picsome/static/js/main.ac80ac6b.chunk.js"
  },
  {
    "revision": "0ebf23dbe67c4226cb9a",
    "url": "/picsome/static/js/runtime-main.8ecb7fe7.js"
  }
]);